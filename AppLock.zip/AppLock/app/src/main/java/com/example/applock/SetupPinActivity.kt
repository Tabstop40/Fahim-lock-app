package com.example.applock

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class SetupPinActivity : AppCompatActivity() {

    private var firstPin: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_setup_pin)

        val title = findViewById<TextView>(R.id.titleText)
        val input = findViewById<EditText>(R.id.pinInput)
        val confirm = findViewById<Button>(R.id.confirmButton)

        confirm.setOnClickListener {
            val pin = input.text.toString()
            if (pin.length != 4) {
                Toast.makeText(this, "৪ ডিজিট দিন", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (firstPin == null) {
                firstPin = pin
                input.text.clear()
                title.text = "আবার PIN দিয়ে নিশ্চিত করুন"
            } else {
                if (pin == firstPin) {
                    PrefsManager.setPin(this, pin)
                    Toast.makeText(this, "PIN সেট হয়েছে", Toast.LENGTH_SHORT).show()
                    finish()
                } else {
                    Toast.makeText(this, "PIN মিলছে না, আবার চেষ্টা করুন", Toast.LENGTH_SHORT).show()
                    firstPin = null
                    input.text.clear()
                    title.text = "একটি ৪ ডিজিটের PIN সেট করুন"
                }
            }
        }
    }
}
