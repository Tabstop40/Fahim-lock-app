package com.example.applock

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.widget.SwitchCompat
import androidx.recyclerview.widget.RecyclerView

class AppListAdapter(
    private val apps: MutableList<AppInfo>,
    private val onToggle: (AppInfo, Boolean) -> Unit
) : RecyclerView.Adapter<AppListAdapter.VH>() {

    inner class VH(view: View) : RecyclerView.ViewHolder(view) {
        val icon: ImageView = view.findViewById(R.id.iconView)
        val label: TextView = view.findViewById(R.id.labelView)
        val lockSwitch: SwitchCompat = view.findViewById(R.id.lockSwitch)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_app, parent, false)
        return VH(v)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val app = apps[position]
        holder.icon.setImageDrawable(app.icon)
        holder.label.text = app.label
        holder.lockSwitch.setOnCheckedChangeListener(null)
        holder.lockSwitch.isChecked = app.isLocked
        holder.lockSwitch.setOnCheckedChangeListener { _, isChecked ->
            app.isLocked = isChecked
            onToggle(app, isChecked)
        }
    }

    override fun getItemCount() = apps.size
}
