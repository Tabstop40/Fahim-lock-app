package com.example.applock

import android.content.Context
import java.security.MessageDigest

object PrefsManager {
    private const val PREFS = "app_lock_prefs"
    private const val KEY_PIN_HASH = "pin_hash"
    private const val KEY_LOCKED_APPS = "locked_apps"

    private fun prefs(ctx: Context) =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    private fun sha256(input: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(input.toByteArray())
        return bytes.joinToString("") { "%02x".format(it) }
    }

    fun isPinSet(ctx: Context): Boolean =
        prefs(ctx).contains(KEY_PIN_HASH)

    fun setPin(ctx: Context, pin: String) {
        prefs(ctx).edit().putString(KEY_PIN_HASH, sha256(pin)).apply()
    }

    fun checkPin(ctx: Context, pin: String): Boolean =
        prefs(ctx).getString(KEY_PIN_HASH, null) == sha256(pin)

    fun getLockedApps(ctx: Context): MutableSet<String> =
        HashSet(prefs(ctx).getStringSet(KEY_LOCKED_APPS, emptySet()) ?: emptySet())

    fun setLockedApps(ctx: Context, apps: Set<String>) {
        prefs(ctx).edit().putStringSet(KEY_LOCKED_APPS, apps).apply()
    }

    fun toggleApp(ctx: Context, packageName: String, locked: Boolean) {
        val set = getLockedApps(ctx)
        if (locked) set.add(packageName) else set.remove(packageName)
        setLockedApps(ctx, set)
    }
}
