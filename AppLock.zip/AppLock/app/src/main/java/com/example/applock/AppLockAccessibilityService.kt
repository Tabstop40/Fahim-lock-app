package com.example.applock

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent

class AppLockAccessibilityService : AccessibilityService() {

    private var lastForegroundPackage: String? = null

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val pkg = event?.packageName?.toString() ?: return
        if (pkg == packageName) return // ignore our own app / lock screen
        if (pkg == lastForegroundPackage) return

        // Leaving a previously-unlocked locked app resets its unlocked state
        lastForegroundPackage?.let { prev ->
            if (prev != pkg && unlockedApps.contains(prev)) {
                unlockedApps.remove(prev)
            }
        }
        lastForegroundPackage = pkg

        val lockedApps = PrefsManager.getLockedApps(this)
        if (lockedApps.contains(pkg) && !unlockedApps.contains(pkg) && PrefsManager.isPinSet(this)) {
            val intent = Intent(this, LockScreenActivity::class.java).apply {
                putExtra(LockScreenActivity.EXTRA_PACKAGE, pkg)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            startActivity(intent)
        }
    }

    override fun onInterrupt() {}

    companion object {
        // packages unlocked for the current foreground session
        private val unlockedApps = mutableSetOf<String>()

        fun markUnlocked(packageName: String) {
            unlockedApps.add(packageName)
        }
    }
}
