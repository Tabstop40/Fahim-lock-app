package com.example.applock

import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.Settings
import android.text.TextUtils
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var permissionBanner: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        recyclerView = findViewById(R.id.appRecyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)

        permissionBanner = findViewById(R.id.permissionBanner)
        permissionBanner.setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        if (!PrefsManager.isPinSet(this)) {
            startActivity(Intent(this, SetupPinActivity::class.java))
        }
    }

    override fun onResume() {
        super.onResume()
        permissionBanner.visibility =
            if (isAccessibilityServiceEnabled()) android.view.View.GONE else android.view.View.VISIBLE
        loadApps()
    }

    private fun isAccessibilityServiceEnabled(): Boolean {
        val expected = "$packageName/${AppLockAccessibilityService::class.java.name}"
        val enabled = Settings.Secure.getString(
            contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        val splitter = TextUtils.SimpleStringSplitter(':')
        splitter.setString(enabled)
        for (s in splitter) {
            if (s.equals(expected, ignoreCase = true)) return true
        }
        return false
    }

    private fun loadApps() {
        val pm = packageManager
        val lockedApps = PrefsManager.getLockedApps(this)

        val apps = pm.getInstalledApplications(PackageManager.GET_META_DATA)
            .filter { it.flags and ApplicationInfo.FLAG_SYSTEM == 0 && it.packageName != packageName }
            .map { info ->
                AppInfo(
                    packageName = info.packageName,
                    label = pm.getApplicationLabel(info).toString(),
                    icon = pm.getApplicationIcon(info),
                    isLocked = lockedApps.contains(info.packageName)
                )
            }
            .sortedBy { it.label.lowercase() }
            .toMutableList()

        recyclerView.adapter = AppListAdapter(apps) { app, isChecked ->
            PrefsManager.toggleApp(this, app.packageName, isChecked)
        }
    }
}
