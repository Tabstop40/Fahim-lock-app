package com.example.applock

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class LockScreenActivity : AppCompatActivity() {

    private var targetPackage: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_lock_screen)

        targetPackage = intent.getStringExtra(EXTRA_PACKAGE)

        val icon = findViewById<ImageView>(R.id.lockedAppIcon)
        val label = findViewById<TextView>(R.id.lockedAppLabel)
        val input = findViewById<EditText>(R.id.pinInput)
        val error = findViewById<TextView>(R.id.errorText)

        targetPackage?.let { pkg ->
            try {
                val pm = packageManager
                val appInfo = pm.getApplicationInfo(pkg, 0)
                icon.setImageDrawable(pm.getApplicationIcon(appInfo))
                label.text = pm.getApplicationLabel(appInfo)
            } catch (e: Exception) {
                label.text = pkg
            }
        }

        input.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                val pin = s.toString()
                if (pin.length == 4) {
                    if (PrefsManager.checkPin(this@LockScreenActivity, pin)) {
                        targetPackage?.let { AppLockAccessibilityService.markUnlocked(it) }
                        finish()
                    } else {
                        error.visibility = TextView.VISIBLE
                        input.text.clear()
                    }
                }
            }
        })
    }

    // Prevent leaving the lock screen via back button without entering PIN
    override fun onBackPressed() {
        moveTaskToBack(true)
    }

    companion object {
        const val EXTRA_PACKAGE = "extra_package"
    }
}
